﻿using HelpdeskDAL;
using System;
using System.Diagnostics;
using System.Reflection;
using System.Collections.Generic;
using System.Text;
namespace HelpdeskViewModels
{
    public class EmployeeViewModel
    {
        private readonly EmployeeDAO _dao;
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }
        public string Timer { get; set; }
        public int DepartmentId { get; set; }
        public string DepartmentName { get; set; }
        public int Id { get; set; }
        public bool IsTech { get; set; }
        public string StaffPicture64 { get; set; }


        public EmployeeViewModel()
        {
            _dao = new EmployeeDAO();
        }

        public void GetByEmail()
        {
            try
            {
                Employees emp = _dao.GetByEmail(Email);
                Title = emp.Title;
                FirstName = emp.FirstName;
                LastName = emp.LastName;
                PhoneNo = emp.PhoneNo;
                Email = emp.Email;
                Id = emp.Id;
                DepartmentId = emp.DepartmentId;
                IsTech = Convert.ToBoolean(emp.IsTech);
                if (emp.StaffPicture != null)
                {
                    StaffPicture64 = Convert.ToBase64String(emp.StaffPicture);
                }
                Timer = Convert.ToBase64String(emp.Timer);

            }
            catch (NullReferenceException nex)
            {
                Debug.WriteLine(nex.Message);
                Email = "not found";
            }

            catch (Exception ex)
            {
                Email = "not found";
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;

            }
        }

        public void GetByLastName()
        {
            try
            {
                Employees emp = _dao.GetByLastName(LastName);
                Title = emp.Title;
                FirstName = emp.FirstName;
                LastName = emp.LastName;
                PhoneNo = emp.PhoneNo;
                Email = emp.Email;
                Id = emp.Id;
                IsTech = Convert.ToBoolean(emp.IsTech);
                DepartmentId = emp.DepartmentId;

                if (emp.StaffPicture != null)
                {
                    StaffPicture64 = Convert.ToBase64String(emp.StaffPicture);
                }
                Timer = Convert.ToBase64String(emp.Timer);

            }
            catch (NullReferenceException nex)
            {
                Debug.WriteLine(nex.Message);
                LastName = "not found";
            }

            catch (Exception ex)
            {
                LastName = "not found";
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }
        }

        public void GetById()
        {
            try
            {
                Employees emp = _dao.GetById(Id);

                Title = emp.Title;
                FirstName = emp.FirstName;
                LastName = emp.LastName;
                PhoneNo = emp.PhoneNo;
                Email = emp.Email;
                Id = emp.Id;
                DepartmentId = emp.DepartmentId;
                IsTech = Convert.ToBoolean(emp.IsTech);
                if (emp.StaffPicture != null)
                {
                    StaffPicture64 = Convert.ToBase64String(emp.StaffPicture);
                }
                Timer = Convert.ToBase64String(emp.Timer);
                
            }
            catch (NullReferenceException nex)
            {
                Debug.WriteLine(nex.Message);
                Email = "not found";
            }

            catch (Exception ex)
            {
                Email = "not found";
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;

            }
        }

        public List<EmployeeViewModel> GetAll()
        {
            
            List<EmployeeViewModel> allVms = new List<EmployeeViewModel>();
            try
            {
                List<Employees> allEmployees = _dao.GetAll();
                
                foreach (Employees emp in allEmployees)
                {
                    
                    EmployeeViewModel empVm = new EmployeeViewModel();
                    empVm.Title = emp.Title;
                    empVm.FirstName = emp.FirstName;
                    empVm.LastName = emp.LastName;
                    empVm.Email = emp.Email;
                    empVm.PhoneNo = emp.PhoneNo;
                    empVm.Id = emp.Id;
                    empVm.DepartmentId = emp.DepartmentId;
                    empVm.DepartmentName = empVm.DepartmentName;             
                    empVm.Timer = Convert.ToBase64String(emp.Timer);
                    if (emp.StaffPicture != null)
                    {
                        empVm.StaffPicture64 = Convert.ToBase64String(emp.StaffPicture);
                    }
                    empVm.IsTech = Convert.ToBoolean(emp.IsTech);
                    allVms.Add(empVm);
                    
                }
            }

            catch (Exception ex)
            {
                //Email = "not found";
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;

            }
            return allVms;
        }


        public void Add()
        {
            Id = -1;
            try
            {
                Employees emp = new Employees
                {
                    Title = Title,
                    FirstName = FirstName,
                    LastName = LastName,
                    PhoneNo = PhoneNo,
                    Email = Email,
                    DepartmentId = DepartmentId,
                    IsTech = IsTech

                };

                Id = _dao.Add(emp);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }
        }


        public int Update()
        {
            UpdateStatus employeesUpdated = UpdateStatus.Failed;
            try
            {
                Employees emp = new Employees
                {
                    Title = Title,
                    FirstName = FirstName,
                    LastName = LastName,
                    PhoneNo = PhoneNo,
                    Email = Email,
                    Id = Id,
                    DepartmentId = DepartmentId,
                    IsTech = IsTech
                };
                if (StaffPicture64 != null)
                {
                    emp.StaffPicture = Convert.FromBase64String(StaffPicture64);
                }
                emp.Timer = Convert.FromBase64String(Timer);
                employeesUpdated = _dao.Update(emp);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }
            return Convert.ToInt16(employeesUpdated);
        }


        public int Delete()
        {
            int employeesdeleted = -1;

            try
            {
                employeesdeleted = _dao.Delete(Id);
            }
            catch (Exception ex)
            {
                LastName = "not found";
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }
            return employeesdeleted;
        }



    }
}

