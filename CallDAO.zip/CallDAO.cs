﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Collections.Generic;
using System.Buffers;
using Microsoft.EntityFrameworkCore;

namespace HelpdeskDAL
{
    public class CallDAO
    {
        readonly IRepository<Call> repository;

        public CallDAO()
        {
            repository = new HelpdeskRepository<Call>();
        }

        public List<Call> GetAll()
        {
            List<Call> allCalls = new List<Call>();

            try
            {
            
                HelpdeskContext _db = new HelpdeskContext();
                allCalls = _db.Calls.ToList();

            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                    MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }

            return allCalls;
        }

        public Call GetById(int id)
        {
            Call selectedCall = null;

            try
            {
                HelpdeskContext _db = new HelpdeskContext();
                selectedCall = _db.Calls.FirstOrDefault(stu => stu.Id == id);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                    MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }

            return selectedCall;
        }


        public List<Call> GetByLastname(string name)
        {
            List<Call> selectedCalls = null;

            try
            {

                selectedCalls = repository.GetByExpression(call => call.Employee.LastName == name);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                    MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }

            return selectedCalls;
        }

        public int Add(Call newCall)
        {

            try
            {
                HelpdeskContext _db = new HelpdeskContext();
                _db.Calls.Add(newCall);
                _db.SaveChanges();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                    MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }

            return newCall.Id;
        }

        public UpdateStatus Update(Call updatedCall)
        {
            UpdateStatus operationStatus = UpdateStatus.Failed;
            try
            {
              
                operationStatus = repository.Update(updatedCall);
            }
            catch (DbUpdateConcurrencyException)
            {
                operationStatus = UpdateStatus.Stale;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                    MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }

            return operationStatus;
        }

        public int Delete(int id)
        {
            int callsDeleted = -1;
            try
            {
                HelpdeskContext _db = new HelpdeskContext();
                Call selectedEmployee = _db.Calls.FirstOrDefault(stu => stu.Id == id);
                _db.Calls.Remove(selectedEmployee);
                callsDeleted = _db.SaveChanges();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " +
                    MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }

            return callsDeleted;
        }
    }
}
