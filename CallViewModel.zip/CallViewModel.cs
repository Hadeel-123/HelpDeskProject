﻿using HelpdeskDAL;
using System;
using System.Diagnostics;
using System.Reflection;
using System.Collections.Generic;
using System.Text;

namespace HelpdeskViewModels
{
    public class CallViewModel
    {
        private readonly CallDAO _dao;
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public int ProblemId { get; set; }
        public string EmployeeName { get; set; }
        public string ProblemDescription { get; set; }
        public string TechName { get; set; }
        public int TechId { get; set; }
        public DateTime DateOpened { get; set; }
        public DateTime? DateClosed { get; set; }
        public bool OpenStatus { get; set; }
        public String Notes { get; set; }
        public string Timer { get; set; }

        public CallViewModel()
        {
            _dao = new CallDAO();
        }

        public void GetById()
        {
            try
            {
                Call call = _dao.GetById(Id);
                
                EmployeeViewModel emp = new EmployeeViewModel();
                EmployeeViewModel techEmpl = new EmployeeViewModel();
                ProblemViewModel prm = new ProblemViewModel();
                         
                // CHECK: 
                emp.Id = call.EmployeeId;
                emp.GetById();

                prm.Id = call.ProblemId;
                prm.GetById();

                techEmpl.Id = call.TechId;
                techEmpl.GetById();

                Id = call.Id;

                EmployeeId = call.EmployeeId;
                ProblemId = call.ProblemId;

                EmployeeName = emp.FirstName+" "+emp.LastName;
                ProblemDescription = prm.Description;
                
                TechId = call.TechId;
                TechName = techEmpl.FirstName+" "+ techEmpl.LastName;
                DateOpened = call.DateOpened;
                DateClosed = call.DateClosed;
                OpenStatus = call.OpenStatus;
                Notes = call.Notes;

                Timer = Convert.ToBase64String(call.Timer);
            }
            catch (NullReferenceException nex)
            {
                Debug.WriteLine(nex.Message);
                throw nex;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }
        }


        public List<CallViewModel> GetAll()
        {
            List<CallViewModel> allVms = new List<CallViewModel>();
            try
            {
                List<Call> allCalls = _dao.GetAll();
                foreach (Call call in allCalls)
                {
                   
                    EmployeeViewModel emp = new EmployeeViewModel();
                    EmployeeViewModel techEmpl = new EmployeeViewModel();
                    ProblemViewModel prm = new ProblemViewModel();

                    emp.Id = call.EmployeeId;
                    emp.GetById();

                    prm.Id = call.ProblemId;
                    prm.GetById();

                    techEmpl.Id = call.TechId;
                    techEmpl.GetById();

                    CallViewModel empVm = new CallViewModel();

                    empVm.Id = call.Id;
                    empVm.EmployeeId = call.EmployeeId;
                    empVm.ProblemId = call.ProblemId;
                    empVm.EmployeeName = emp.FirstName + " " + emp.LastName;
                    empVm.ProblemDescription = prm.Description;
                    empVm.TechName = techEmpl.FirstName + " " + techEmpl.LastName;
                    empVm.TechId = call.TechId;
                    empVm.DateOpened = call.DateOpened;
                    empVm.DateClosed = call.DateClosed;
                    empVm.OpenStatus = call.OpenStatus;
                    empVm.Notes = call.Notes;

                    empVm.Timer = Convert.ToBase64String(call.Timer);
                    
                    allVms.Add(empVm);
                }
            }

            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }
            return allVms;
        }
        public List<CallViewModel> GetByLastname(string empname)
        {
            List<CallViewModel> allVms = new List<CallViewModel>();
            try
            {
                List<Call> allCalls = _dao.GetByLastname(empname);
                foreach (Call call in allCalls)
                {
                    CallViewModel empVm = new CallViewModel
                    {
                        Id = call.Id,
                        EmployeeId = call.EmployeeId,
                        ProblemId = call.ProblemId,
                        EmployeeName = call.Employee.LastName,
                        ProblemDescription = call.Problem.Description,
                        TechName = call.Tech.LastName,
                        TechId = call.TechId,
                        DateOpened = call.DateOpened,
                        DateClosed = call.DateClosed,
                        OpenStatus = call.OpenStatus,
                        Notes = call.Notes,

                        Timer = Convert.ToBase64String(call.Timer),
                    };
                    allVms.Add(empVm);
                }
            }

            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }
            return allVms;
        }

        public void Add()
        {
            Id = -1;
            try
            {
                Call call = new Call
                {
                    EmployeeId = EmployeeId,
                    ProblemId = ProblemId,
                    TechId = TechId,
                    DateOpened = DateOpened,
                    DateClosed = DateClosed,
                    OpenStatus = OpenStatus,
                    Notes = Notes

                };

                Id = _dao.Add(call);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }
        }


        public int Update()
        {
            
            UpdateStatus callUpdated = UpdateStatus.Failed;
            try
            {
                Call call = new Call
                {
                    EmployeeId = EmployeeId,
                    ProblemId = ProblemId,
                    TechId = TechId,
                    DateOpened = DateOpened,
                    DateClosed = DateClosed,
                    OpenStatus = OpenStatus,
                    Notes = Notes,
                    Id = Id
                };
                
                if (Timer != null)
                {
                    call.Timer = Convert.FromBase64String(Timer);
                }
                callUpdated = _dao.Update(call);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }
            return Convert.ToInt16(callUpdated);
        }


        public int Delete()
        {
            int calldeleted = -1;

            try
            {
                calldeleted = _dao.Delete(Id);
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Problem in " + GetType().Name + " " + MethodBase.GetCurrentMethod().Name + " " + ex.Message);
                throw ex;
            }
            return calldeleted;
        }
    }
}
