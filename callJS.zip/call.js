﻿$(function () {  // employeeaddupdate.js

    const getAll = async (msg) => {
        try {
            $("#callList").text("Finding employee Information...");
            let response = await fetch(`api/call`);
            if (response.ok) {
                let payload = await response.json();
                console.log(payload)
                buildCallList(payload);
                msg === "" ?
                    $("#status").text("Calls Loaded") : $("#status").text(`${msg} - Calls Loaded`);
            } else if (response.status !== 404) {
                let problemJson = await response.Json();
                errorRtn(problemJson, response.status);
            } else {
                $("#status").text("no such path on server");
            } //else
        } catch (error) {
            $("status").text(error.message);
        }
    };//getAll

    //For Search
    const getByEmp = async (msg, empname) => {
        try {
            $("#callList").text("Finding employee Information...");
            let response = await fetch(`api/call/${empname}`);
            if (response.ok) {
                let payload = await response.json();
                buildCallList(payload);
                msg === "" ?
                    $("#status").text("Calls Loaded") : $("#status").text(`${msg} - Calls Loaded`);
            } else if (response.status !== 404) {
                let problemJson = await response.Json();
                errorRtn(problemJson, response.status);
            } else {
                $("#status").text("no such path on server");
            } //else
        } catch (error) {
            $("status").text(error.message);
        }
    };
    //Search



    var textBoxSearch = document.getElementById("empName");
    textBoxSearch.addEventListener("keyup", e => {
        getByEmp("", textBoxSearch.value);
    });



    $("#empName").keyup(() => {
        let alldata = JSON.parse(sessionStorage.getItem("allcalls"));
        let filtereddata = alldata.filter((stu) => stu.lastname.match(new RegExp($("#empName").val(), 'i')));
        buildStudentList(filtereddata, false);
    }); //srch keyup

    $("#problemSelect").on('change', validate);
    $("#employeeSelect").on('change', validate);
    $("#techSelect").on('change', validate);
    $("#notesll").on('change', validate);


    const loadProblems = () => {
        const getProblems = async () => {
            try {
                //get division data
                response = await fetch(`api/problem`);
                if (response.ok) {
                    let divs = await response.json();
                    sessionStorage.setItem("problems", JSON.stringify(divs));
                } else if (response.status !== 404) {
                    let problemJson = await response.json();
                    errorRtn(problemJson, response.status);
                } else {
                    $("#status").text("no such path on server");
                } //else
            }
            catch (eror) {
                $("#status").text(error.message);
            }
        }
        
        getProblems();
        html = '';
        $('#problemSelect').empty();
        let alldivisions = JSON.parse(sessionStorage.getItem('problems'));
        console.log(alldivisions)
        if (alldivisions) {
            alldivisions.map(div => html += `<option value="${div.id}">${div.description}</option>`);
        }
        $('#problemSelect').append(html);
       
    }; 

    const loadEmp = () => {
        const getEmployees = async () => {
            try {
                //get division data
                response = await fetch(`api/employee`);
                if (response.ok) {
                    let divs = await response.json();
                    sessionStorage.setItem("employeeSelect", JSON.stringify(divs));
                } else if (response.status !== 404) {
                    let problemJson = await response.json();
                    errorRtn(problemJson, response.status);
                } else {
                    $("#status").text("no such path on server");
                } //else
            }
            catch (eror) {
                $("#status").text(error.message);
            }
        }

        getEmployees();
        html = '';
        $('#employeeSelect').empty();
        let alldivisions = JSON.parse(sessionStorage.getItem('employeeSelect'));
        console.log(alldivisions)
        if (alldivisions) {
            alldivisions.map(div => html += `<option value="${div.id}">${div.lastName}</option>`);
        }
        $('#employeeSelect').append(html);
      
    }; 

    const loadTech = () => {
        html = '';
        $('#techSelect').empty();
        let technitians = JSON.parse(sessionStorage.getItem('employeeSelect'));
        
        if (technitians) {
            technitians.map(div => {
                if (div.isTech) {
                    html += `<option value="${div.id}">${div.lastName}</option>`
                }
            });
        }
        $('#techSelect').append(html);
      
    }; 


    const setupForUpdate = (id, call) => {
        console.log(call)
        clearModalFields();
        loadEmp()
        loadTech()
        loadProblems()
        $("#actionbutton").val("update");
        $("#modaltitle").html("<h4>Update Call</h4>");
        $(".updateHide").show();
        $("#actionbuttonDelete").show();
        
        //data.map(call => {
            if (call.id === parseInt(id)) {
                $("#problemSelect").val(call.problemId);
                $("#employeeSelect").val(call.employeeId);
                $("#techSelect").val(call.techId);
                $("#notes").val(call.notes);
                $("#opendDate").html(formatDate(call.dateOpened).replace("T", " "));
                sessionStorage.setItem("dateOpened", formatDate(call.dateOpened));
                if (!call.openStatus)
                {
                    $("#closeCall").prop("checked", true);
                    $("#closeCall").attr("disabled", true);
                    $("#closedDate").html(formatDate(call.dateClosed).replace("T", " "));
                    $("#problemSelect").attr("disabled", true);
                    $("#employeeSelect").attr("disabled", true);
                    $("#techSelect").attr("disabled", true);
                    $("#notes").attr("readonly", true);
                    $("#actionbutton").hide();
                }
                sessionStorage.setItem("id", call.id);
                sessionStorage.setItem("Timer", call.timer);

                $("#modalstatus").text("update data");
                $("#theModal").modal("toggle");
            } // if
      //  }); // data.map
    }; // setupForUpdate

    const setupForAdd = () => {
        $("#actionbutton").val("add");
        $("#modaltitle").html("<h4>Add Call</h4>");
        $("#theModal").modal("toggle");
        $("#modalstatus").text("add new call");
        $(".updateHide").hide();
        $("#opendDate").html(formatDate().replace("T", " "));
        $("#actionbuttonDelete").hide();
        sessionStorage.setItem("dateOpened", formatDate());
        clearModalFields();
    }; // setupForAdd

    const clearModalFields = () => {
        $("#notes").val("");
        $("#closeCall").prop("checked", false);
        $("#closedDate").html();
        $("#problemSelect").attr("disabled", false);
        $("#problemSelect").val("");
        $("#employeeSelect").attr("disabled", false);
        $("#employeeSelect").val("");
        $("#techSelect").attr("disabled", false);
        $("#techSelect").val("");
        $("#notes").attr("readonly", false);
        $("#actionbutton").show();
        sessionStorage.removeItem("id");
        sessionStorage.removeItem("Timer");
    }; //clearModalFields

    const formatDate = (date) => {
        let d;
        (date === undefined) ? d = new Date() : d = new Date(Date.parse(date));
        let _day = d.getDate();
        if (_day < 10) { _day = "0" + _day; }
        let _month = d.getMonth() + 1;
        if (_month < 10) { _month = "0" + _month; }
        let _year = d.getFullYear();
        let _hour = d.getHours();
        if (_hour < 10) { _hour = "0" + _hour; }
        let _min = d.getMinutes();
        if (_min < 10) { _min = "0" + _min; }
        return _year + "-" + _month + "-" + _day + "T" + _hour + ":" + _min;
    }
    function validate() {
        var x = 0;
        if ($("#problemSelect").val() == null) {
            $("#errorProb").html("Select Problem");
            x = 1;
        }
        else {
            $("#errorProb").html("");
        }
        if ($("#employeeSelect").val() == null) {
            $("#errorEmp").html("Select Employee");
            x = 1;
        }
        else {
            $("#errorEmp").html("");
        }
        if ($("#techSelect").val() == null) {
            $("#errorTech").html("Select Tech");
            x = 1;
        }
        else {
            $("#errorTech").html("");
        }
        if ($("#notes").val().length < 1 || $("#notes").val().length > 250) {
            $("#errorNotes").html("required 1 - 250 chars");
            x = 1;
        }
        else {
            $("#errorNotes").html("");
        }
        return x;
    }
    const add = async () => {
        try {
            call = new Object();
            call.problemId = parseInt($("#problemSelect").val());
            call.employeeId = parseInt($("#employeeSelect").val());
            call.techId = parseInt($("#techSelect").val());
            call.dateOpened = sessionStorage.getItem("dateOpened");
            call.notes = $("#notes").val();
            call.openStatus = true;
            call.timer = null;
     
            var x = validate();
            if (x == 0) {
                console.log(call);
                let response = await fetch(`api/call`, {
                    method: "POST",
                    headers: { "Content-Type": "application/json; charset=utf-8" },
                    body: JSON.stringify(call)
                });


                if (response.ok) // or check for response.status
                {
                    let data = await response.json();
                    getAll(data.msg);
                } else if (response.status !== 404) { 
                    let problemJson = await response.json();
                    errorRtn(problemJson, response.status);
                } else { // else 404 not found
                    $("#status").text("no such path on server");
                }
                $("#theModal").modal("toggle");
            }// else
        } catch (error) {
            $("#status").text(error.message);
        }  // try/catch

    }; // add
    $("#closeCall").click(() => {
        if ($("#closeCall").is(":checked")) {
            $("#closedDate").html(formatDate().replace("T", " "));
            sessionStorage.setItem("dateClosed", formatDate());
        }
        else
        {
            $("#closedDate").html("");
            sessionStorage.setItem("dateClosed","");
        }
    });
    const update = async () => {
        try {
            // set up a new client side instance of employee
            call = new Object();
            call.id = parseInt(sessionStorage.getItem("id"));
            call.problemId = parseInt($("#problemSelect").val());
            call.employeeId = parseInt($("#employeeSelect").val());
            call.techId = parseInt($("#techSelect").val());
            call.dateOpened = sessionStorage.getItem("dateOpened");
            call.notes = $("#notes").val();
            call.openStatus = true;
            call.timer = sessionStorage.getItem("Timer");
            if ($("#closeCall").is(":checked"))
            {
                call.openStatus = false;
                call.dateClosed = sessionStorage.getItem("dateClosed");
            }

            // send the updated back to the server asynchronously using PUT 
            console.log(call);
            let response = await fetch(`api/call`, {
                method: "PUT",
                headers: { "Content-Type": "application/json; charset=utf-8" },
                body: JSON.stringify(call)
            });


            if (response.ok) // or check for response.status 
            {
                let data = await response.json();
                getAll(data.msg);
            } else if (response.status !== 404) { // probably some other client side error
                let problemJson = await response.json();
                errorRtn(problemJson, response.status);
            } else { // else 404 not found
                $("#status").text("no such path on server");
            } // else
        } catch (error) {
            $("#status").text(error.message);
        }  // try/catch
        $("#theModal").modal("toggle");

    }

    const deleteCall = async () => {
        try {
            let response = await fetch(`api/call/${sessionStorage.getItem('id')}`, {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json; charset=utf-8' }
            });

            if (response.ok) // or check for response.status
            {
                let data = await response.json();
                getAll(data.msg);
            } else if (response.status !== 404) { // probably some other client side error
                let problemJson = await response.json();
                errorRtn(problemJson, response.status);
            } else { // else 404 not found
                $("#status").text("no such path on server");
            } // else
        } catch (error) {
            $("#status").text(error.message);
        }  // try/catch
        $("#theModal").modal("toggle");
    }

    $("#actionbutton").click(() => {
        $("#actionbutton").val() === "update" ? update() : add();
    });



    $('[data-toggle=confirmation]').confirmation({ rootSelector: '[data-toggle=confirmation]' });

    $('#actionbuttonDelete').click(() => deleteCall());

    $("#callList").click((e) => {
        if (!e) e = window.event;
        let id = e.target.parentNode.id;
        if (id === "callList" || id === "") {
            id = e.target.id;
        } // Clicked on row somewhere else


       

        const getCall = async (id) => {
            try {
                let response = await fetch(`api/call/${id}`);
                if (response.ok) {
                    let callData = await response.json();
                    console.log(callData)
                    sessionStorage.setItem("selectedCall", JSON.stringify(callData));
                } else if (response.status !== 400) {
                    let problemJson = await response.json();
                    errorRtn(problemJson, response.status);
                } else {
                    $("#status").text("no such path on server");
                }
            }
            catch (eror) {
                $("#status").text(error.message);
            }
        }
        if(id!="-1")
            getCall(id);

        if (id !== "status" && id !== "heading" && id !="-1") {
            let data = JSON.parse(sessionStorage.getItem("selectedCall"));
            setupForUpdate(id, data);
        } else {
            return false; // Ignore if they clicked on heading or status
        }
    });


    const buildCallList = (data) => {
        $("#callList").empty();
        div = $(`<div class="list-group-item text-white bg-secondary row d-flex" id="status"></div>
                     <div class= "list-group-item row d-flex text-center" id="heading">
                     <div class="col-4 h4">Date</div>
                     <div class="col-4 h4">For</div>
                     <div class="col-4 h4">Problem</div>
                      </div>`);
        div.appendTo($("#callList"));
        sessionStorage.setItem("allCalls", JSON.stringify(data));
        btn = $("<button class='list-group-item row d-flex actionbuttonAdd' id='-1'><div class='col-12 text-left'>...click to add call</div></button>");
        btn.appendTo($("#callList"));
        data.map(call => {
            btn = $(`<button class="list-group-item row d-flex" id="${call.id}">`);
            btn.html(`<div class="col-4" id="callDate${call.id}">${call.dateOpened}</div>
                          <div class="col-4" id="callFor${call.id}">${call.employeeName}</div>
                          <div class="col-4" id="callProblem${call.id}">${call.problemDescription}</div>`
            );
            btn.appendTo($("#callList"));
        });//map
        $(".actionbuttonAdd").click(() => {
            setupForAdd();
        });
    };// buildCallList

    getAll("");
    loadProblems();
    loadEmp();
    loadTech();
    console.log("LOADING DATA")
  

}); // jQuery ready method

// server was reached but server had a problem with the call
const errorRtn = (problemJson, status) => {
    if (status > 499) {
        $("#status").text("Problem server side, see debug console");
    } else {
        let keys = Object.keys(problemJson.errors)
        problem = {
            status: status,
            statusText: problemJson.errors[keys[0]][0], // first error
        };
        $("#status").text("Problem client side, see browser console");
        console.log(problem);
    } // else
}



